// MindEase - Mental Wellness App
// Main Application JavaScript
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

// ============================================
// API Configuration
// ============================================
const API_BASE = '/api';
let realtimeClient = null;
let realtimeChannel = null;

// ============================================
// Device ID Management (for data persistence)
// ============================================
const DEVICE_ID_KEY = 'mindease-device-id';

function getDeviceId() {
    let deviceId = localStorage.getItem(DEVICE_ID_KEY);
    if (!deviceId) {
        deviceId = crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).substr(2);
        localStorage.setItem(DEVICE_ID_KEY, deviceId);
    }
    return deviceId;
}

// ============================================
// State Management (localStorage-based with API sync)
// ============================================
const STORAGE_KEY = 'mindease-storage';

const defaultState = {
    hasSeenWelcome: false,
    isDarkMode: false,
    profile: { name: '' },
    journalEntries: [],
    assessmentResults: [],
    likedQuotes: [],
    currentScreen: 'welcome'
};

function getState() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        return stored ? { ...defaultState, ...JSON.parse(stored) } : { ...defaultState };
    } catch {
        return { ...defaultState };
    }
}

function setState(updates) {
    const state = getState();
    const newState = { ...state, ...updates };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newState));
    return newState;
}

// ============================================
// API Functions
// ============================================
async function apiGet(endpoint) {
    try {
        const deviceId = getDeviceId();
        const response = await fetch(`${API_BASE}${endpoint}?device_id=${deviceId}`);
        if (!response.ok) throw new Error('API error');
        return await response.json();
    } catch (error) {
        console.log('[v0] API GET error:', error);
        return null;
    }
}

async function apiPost(endpoint, data) {
    try {
        const deviceId = getDeviceId();
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...data, device_id: deviceId })
        });
        if (!response.ok) throw new Error('API error');
        return await response.json();
    } catch (error) {
        console.log('[v0] API POST error:', error);
        return null;
    }
}

async function apiPut(endpoint, data) {
    try {
        const deviceId = getDeviceId();
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...data, device_id: deviceId })
        });
        if (!response.ok) throw new Error('API error');
        return await response.json();
    } catch (error) {
        console.log('[v0] API PUT error:', error);
        return null;
    }
}

async function apiDelete(endpoint) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'DELETE'
        });
        if (!response.ok) throw new Error('API error');
        return await response.json();
    } catch (error) {
        console.log('[v0] API DELETE error:', error);
        return null;
    }
}

// Sync data from backend to local state
async function syncFromBackend() {
    try {
        const [journalEntries, assessmentResults, profile, likedQuotes] = await Promise.all([
            apiGet('/journal'),
            apiGet('/assessments'),
            apiGet('/profile'),
            apiGet('/liked-quotes')
        ]);
        
        const updates = {};
        if (journalEntries) updates.journalEntries = journalEntries;
        if (assessmentResults) updates.assessmentResults = assessmentResults;
        if (profile) updates.profile = profile;
        if (likedQuotes) {
            // Convert from DB format to app format
            updates.likedQuotes = likedQuotes.map(lq => ({
                text: lq.quote_text,
                author: lq.quote_author
            }));
        }
        
        if (Object.keys(updates).length > 0) {
            setState(updates);
        }
    } catch (error) {
        console.log('[v0] Sync error:', error);
    }
}

// ============================================
// Icons (SVG)
// ============================================
const icons = {
    menu: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>`,
    arrowLeft: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>`,
    chevronLeft: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>`,
    chevronRight: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>`,
    clipboard: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/></svg>`,
    book: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/></svg>`,
    history: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/></svg>`,
    sparkles: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/><path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/></svg>`,
    user: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
    home: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
    heart: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
    heartFilled: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>`,
    copy: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>`,
    share: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>`,
    check: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>`,
    checkCircle: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>`,
    alertTriangle: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>`,
    info: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>`,
    phone: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`,
    edit: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>`,
    trash: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>`,
    moon: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>`,
    sun: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>`,
    trendingUp: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></svg>`,
    trendingDown: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/></svg>`,
    minus: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>`,
    x: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`,
    refresh: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>`,
    activity: `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`
};

// ============================================
// Data
// ============================================
const moods = [
    { value: 'happy', label: 'Happy', emoji: '😊', color: 'var(--mood-happy)' },
    { value: 'calm', label: 'Calm', emoji: '😌', color: 'var(--mood-calm)' },
    { value: 'neutral', label: 'Neutral', emoji: '😐', color: 'var(--mood-neutral)' },
    { value: 'sad', label: 'Sad', emoji: '😢', color: 'var(--mood-sad)' },
    { value: 'anxious', label: 'Anxious', emoji: '😰', color: 'var(--mood-anxious)' },
    { value: 'angry', label: 'Angry', emoji: '😠', color: 'var(--mood-angry)' }
];

// Master list of all quotes (75 quotes for rotation)
const allQuotes = [
    // Set 1 (1-15)
    { text: "You are stronger than you know, braver than you believe, and more loved than you can imagine.", author: "A.A. Milne" },
    { text: "Take a deep breath. It's just a bad day, not a bad life.", author: "Unknown" },
    { text: "Healing is not linear. Some days will be harder than others, and that's okay.", author: "Unknown" },
    { text: "Be gentle with yourself. You're doing the best you can.", author: "Unknown" },
    { text: "Your feelings are valid. It's okay to not be okay sometimes.", author: "Unknown" },
    { text: "Every storm runs out of rain. This too shall pass.", author: "Maya Angelou" },
    { text: "You don't have to control your thoughts. You just have to stop letting them control you.", author: "Dan Millman" },
    { text: "Self-care is not selfish. You cannot serve from an empty vessel.", author: "Eleanor Brown" },
    { text: "Progress, not perfection, is what we should be asking of ourselves.", author: "Julia Cameron" },
    { text: "The only way out is through. Keep going.", author: "Robert Frost" },
    { text: "You are not your anxiety. You are not your depression. You are you.", author: "Unknown" },
    { text: "Rest when you need to. The world can wait.", author: "Unknown" },
    { text: "Small steps every day lead to big changes over time.", author: "Unknown" },
    { text: "Your mental health is a priority. Your happiness is essential. Your self-care is a necessity.", author: "Unknown" },
    { text: "It's okay to ask for help. Reaching out is a sign of strength, not weakness.", author: "Unknown" },
    // Set 2 (16-30)
    { text: "The greatest glory in living lies not in never falling, but in rising every time we fall.", author: "Nelson Mandela" },
    { text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt" },
    { text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson" },
    { text: "You have been assigned this mountain to show others it can be moved.", author: "Mel Robbins" },
    { text: "The wound is the place where the light enters you.", author: "Rumi" },
    { text: "Sometimes the bravest thing you can do is simply get out of bed.", author: "Unknown" },
    { text: "Courage doesn't always roar. Sometimes courage is the quiet voice saying, 'I will try again tomorrow.'", author: "Mary Anne Radmacher" },
    { text: "You are allowed to be both a masterpiece and a work in progress simultaneously.", author: "Sophia Bush" },
    { text: "Happiness can be found even in the darkest of times, if one only remembers to turn on the light.", author: "Albus Dumbledore" },
    { text: "The only impossible journey is the one you never begin.", author: "Tony Robbins" },
    { text: "Not all storms come to disrupt your life. Some come to clear your path.", author: "Paulo Coelho" },
    { text: "You don't have to be positive all the time. It's perfectly okay to feel sad, angry, annoyed, or frustrated.", author: "Lori Deschene" },
    { text: "Mental health problems don't define who you are. They are something you experience.", author: "Unknown" },
    { text: "One small crack does not mean that you are broken; it means that you were put to the test and you didn't fall apart.", author: "Linda Poindexter" },
    { text: "The sun will rise and we will try again.", author: "Unknown" },
    // Set 3 (31-45)
    { text: "You are worth more than your productivity.", author: "Unknown" },
    { text: "In the middle of difficulty lies opportunity.", author: "Albert Einstein" },
    { text: "Nothing is permanent in this wicked world, not even our troubles.", author: "Charlie Chaplin" },
    { text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe" },
    { text: "The human spirit is stronger than anything that can happen to it.", author: "C.C. Scott" },
    { text: "Tough times never last, but tough people do.", author: "Robert H. Schuller" },
    { text: "It does not matter how slowly you go as long as you do not stop.", author: "Confucius" },
    { text: "You cannot swim for new horizons until you have courage to lose sight of the shore.", author: "William Faulkner" },
    { text: "When everything seems to be going against you, remember that the airplane takes off against the wind, not with it.", author: "Henry Ford" },
    { text: "Your calm mind is the ultimate weapon against your challenges.", author: "Bryant McGill" },
    { text: "Out of suffering have emerged the strongest souls; the most massive characters are seared with scars.", author: "Khalil Gibran" },
    { text: "Difficult roads often lead to beautiful destinations.", author: "Zig Ziglar" },
    { text: "Even the darkest night will end and the sun will rise.", author: "Victor Hugo" },
    { text: "You gain strength, courage, and confidence by every experience in which you really stop to look fear in the face.", author: "Eleanor Roosevelt" },
    { text: "Sometimes you have to let go of the picture of what you thought life would be like and learn to find joy in the story you are living.", author: "Rachel Marie Martin" },
    // Set 4 (46-60)
    { text: "You are enough just as you are. Each emotion you feel, everything in your life, everything you do or do not do, it's all okay.", author: "Haemin Sunim" },
    { text: "Stars can't shine without darkness.", author: "D.H. Sidebottom" },
    { text: "Be patient with yourself. Self-growth is tender; it's holy ground. There's no greater investment.", author: "Stephen Covey" },
    { text: "The greatest weapon against stress is our ability to choose one thought over another.", author: "William James" },
    { text: "Breathe. Let go. And remind yourself that this very moment is the only one you know you have for sure.", author: "Oprah Winfrey" },
    { text: "Almost everything will work again if you unplug it for a few minutes, including you.", author: "Anne Lamott" },
    { text: "There is hope, even when your brain tells you there isn't.", author: "John Green" },
    { text: "You don't have to see the whole staircase, just take the first step.", author: "Martin Luther King Jr." },
    { text: "Owning our story and loving ourselves through that process is the bravest thing we'll ever do.", author: "Brene Brown" },
    { text: "Ring the bells that still can ring. Forget your perfect offering. There is a crack in everything. That's how the light gets in.", author: "Leonard Cohen" },
    { text: "When we are no longer able to change a situation, we are challenged to change ourselves.", author: "Viktor Frankl" },
    { text: "The lotus flower blooms most beautifully from the deepest and thickest mud.", author: "Buddhist Proverb" },
    { text: "What we achieve inwardly will change outer reality.", author: "Plutarch" },
    { text: "Life isn't about waiting for the storm to pass. It's about learning how to dance in the rain.", author: "Vivian Greene" },
    { text: "Don't believe everything you think. Thoughts are just that - thoughts.", author: "Allan Lokos" },
    // Set 5 (61-75)
    { text: "Rock bottom became the solid foundation on which I rebuilt my life.", author: "J.K. Rowling" },
    { text: "The only person you are destined to become is the person you decide to be.", author: "Ralph Waldo Emerson" },
    { text: "Worry does not empty tomorrow of its sorrow, it empties today of its strength.", author: "Corrie Ten Boom" },
    { text: "No matter how you feel, get up, dress up, show up, and never give up.", author: "Regina Brett" },
    { text: "Promise me you'll always remember: You're braver than you believe, and stronger than you seem, and smarter than you think.", author: "A.A. Milne" },
    { text: "Act as if what you do makes a difference. It does.", author: "William James" },
    { text: "You have within you right now, everything you need to deal with whatever the world throws at you.", author: "Brian Tracy" },
    { text: "The struggle you're in today is developing the strength you need for tomorrow.", author: "Robert Tew" },
    { text: "Feelings are just visitors. Let them come and go.", author: "Mooji" },
    { text: "Sometimes the most productive thing you can do is rest.", author: "Mark Black" },
    { text: "You can't pour from an empty cup. Take care of yourself first.", author: "Unknown" },
    { text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb" },
    { text: "Where there is no struggle, there is no strength.", author: "Oprah Winfrey" },
    { text: "What consumes your mind controls your life.", author: "Unknown" },
    { text: "Every day may not be good, but there is something good in every day.", author: "Alice Morse Earle" }
];

const QUOTES_PER_SESSION = 15;
const SESSION_QUOTES_KEY = 'mindease-session-quotes';
const SHOWN_QUOTES_KEY = 'mindease-shown-quotes';

// Get or generate session quotes
function getSessionQuotes() {
    // Check if we already have session quotes
    const sessionData = sessionStorage.getItem(SESSION_QUOTES_KEY);
    if (sessionData) {
        return JSON.parse(sessionData);
    }
    
    // Get previously shown quote indices from localStorage
    let shownIndices = [];
    try {
        const stored = localStorage.getItem(SHOWN_QUOTES_KEY);
        shownIndices = stored ? JSON.parse(stored) : [];
    } catch {
        shownIndices = [];
    }
    
    // Get available quotes (not yet shown)
    let availableIndices = allQuotes.map((_, i) => i).filter(i => !shownIndices.includes(i));
    
    // If we've shown all quotes, reset and start fresh
    if (availableIndices.length < QUOTES_PER_SESSION) {
        shownIndices = [];
        availableIndices = allQuotes.map((_, i) => i);
        localStorage.setItem(SHOWN_QUOTES_KEY, JSON.stringify([]));
    }
    
    // Shuffle available indices and pick 15
    const shuffled = availableIndices.sort(() => Math.random() - 0.5);
    const selectedIndices = shuffled.slice(0, QUOTES_PER_SESSION);
    
    // Store selected quotes for this session
    const sessionQuotes = selectedIndices.map(i => allQuotes[i]);
    sessionStorage.setItem(SESSION_QUOTES_KEY, JSON.stringify(sessionQuotes));
    
    // Update shown quotes in localStorage
    const newShownIndices = [...shownIndices, ...selectedIndices];
    localStorage.setItem(SHOWN_QUOTES_KEY, JSON.stringify(newShownIndices));
    
    return sessionQuotes;
}

// Get current session's quotes
let quotes = getSessionQuotes();

const assessmentQuestions = [
    "In the last month, how often have you been upset because of something that happened unexpectedly?",
    "In the last month, how often have you felt that you were unable to control the important things in your life?",
    "In the last month, how often have you felt nervous and stressed?",
    "In the last month, how often have you felt confident about your ability to handle your personal problems?",
    "In the last month, how often have you felt that things were going your way?",
    "In the last month, how often have you found that you could not cope with all the things that you had to do?",
    "In the last month, how often have you been able to control irritations in your life?",
    "In the last month, how often have you felt that you were on top of things?",
    "In the last month, how often have you been angered because of things that happened that were outside of your control?",
    "In the last month, how often have you felt difficulties were piling up so high that you could not overcome them?"
];

const answerOptions = [
    { value: 0, label: 'Never' },
    { value: 1, label: 'Almost Never' },
    { value: 2, label: 'Sometimes' },
    { value: 3, label: 'Fairly Often' },
    { value: 4, label: 'Very Often' }
];

const reverseScoreQuestions = [3, 4, 6, 7];

const emergencyContacts = [
    { name: 'National Mental Health Crisis Hotline', number: '1553' },
    { name: 'DOH Mental Health Hotline', number: '0917-899-8727' },
    { name: 'Hopeline Philippines', number: '0917-558-4673' },
    { name: 'Calbayog City Health Office', number: '(055) 209-2158' }
];

const severityInfo = {
    normal: {
        title: 'Low Stress Level',
        description: "Your stress levels appear to be within a healthy range. You're managing life's challenges well.",
        tips: ['Continue practicing healthy coping mechanisms', 'Maintain your regular sleep schedule', 'Keep engaging in activities you enjoy', 'Stay connected with supportive people']
    },
    moderate: {
        title: 'Moderate Stress Level',
        description: "You're experiencing moderate stress. This is common and manageable with some adjustments.",
        tips: ['Practice deep breathing exercises daily', 'Take regular breaks during work or study', 'Consider starting a mindfulness or meditation practice', 'Talk to someone you trust about what you are feeling', 'Prioritize getting enough sleep']
    },
    severe: {
        title: 'High Stress Level',
        description: "You're experiencing significant stress that may be affecting your daily life. Consider seeking support.",
        tips: ['Reach out to a mental health professional', 'Reduce commitments where possible', 'Practice self-compassion and be gentle with yourself', 'Avoid caffeine and alcohol', 'Establish a consistent daily routine', 'Consider talking to a counselor or therapist']
    },
    'extremely-severe': {
        title: 'Very High Stress Level',
        description: "Your stress levels are very high. Please reach out for professional support. You don't have to face this alone.",
        tips: ['Contact a mental health professional immediately', 'Reach out to a trusted friend or family member', 'Call one of the crisis hotlines listed below', 'Remember that seeking help is a sign of strength']
    }
};

const severityConfig = {
    'normal': { label: 'Low Stress', class: 'severity-normal', bg: 'bg-severity-normal', remark: 'Healthy stress levels' },
    'moderate': { label: 'Moderate', class: 'severity-moderate', bg: 'bg-severity-moderate', remark: 'Manageable with self-care' },
    'severe': { label: 'High Stress', class: 'severity-severe', bg: 'bg-severity-severe', remark: 'Consider seeking support' },
    'extremely-severe': { label: 'Very High', class: 'severity-extreme', bg: 'bg-severity-extreme', remark: 'Professional help recommended' }
};

// ============================================
// Utility Functions
// ============================================
function formatDate(dateStr, format = 'long') {
    const date = new Date(dateStr);
    if (format === 'long') {
        return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    }
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function formatTime(dateStr) {
    return new Date(dateStr).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

function generateId() {
    return crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function showToast(message, type = 'default') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function getMoodData(mood) {
    return moods.find(m => m.value === mood) || moods[2];
}

function debounce(fn, delay = 500) {
    let timer = null;
    return (...args) => {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => fn(...args), delay);
    };
}

// ============================================
// Screen Renderers
// ============================================

// Welcome Screen
function renderWelcomeScreen() {
    return `
        <div class="welcome-screen">
            <div class="welcome-logo-container">
                <img src="/images/logo.svg" alt="MindEase Logo" class="welcome-logo">
                <div class="welcome-logo-ring"></div>
            </div>
            <h1 class="welcome-title">MindEase</h1>
            <p class="welcome-subtitle">Your Mental Wellness Companion</p>
            <p class="welcome-description">
                Track your mood, assess your wellbeing, and journal your thoughts in a safe, supportive space.
            </p>
            <button class="btn btn-primary btn-lg" onclick="app.handleGetStarted()">
                Get Started
            </button>
        </div>
    `;
}

// Home Screen
function renderHomeScreen() {
    const state = getState();
    const greeting = state.profile.name ? `Hello, ${state.profile.name}` : 'Welcome back';
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.toggleSidebar()">
                    ${icons.menu}
                </button>
                <div class="header-title">
                    <img src="/images/logo.svg" alt="MindEase" class="header-logo">
                    MindEase
                </div>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            <div class="mb-6">
                <h2>${greeting}</h2>
                <p class="mt-1">How are you feeling today?</p>
            </div>
            
            <div class="card mb-6">
                <div class="card-content">
                    <h3 class="text-sm text-center mb-4" style="color: var(--muted);">Mood Calendar</h3>
                    ${renderMoodCalendar()}
                </div>
            </div>
            
            <div class="mb-6">
                ${renderComfortCorner()}
            </div>
        </main>
        
        ${renderBottomNav()}
        ${renderSidebar()}
    `;
}

// Mood Calendar
function renderMoodCalendar() {
    const state = getState();
    const now = new Date();
    const year = app.calendarYear || now.getFullYear();
    const month = app.calendarMonth !== undefined ? app.calendarMonth : now.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDay = firstDay.getDay();
    const daysInMonth = lastDay.getDate();
    
    const monthName = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    let calendarHTML = `
        <div class="mood-calendar">
            <div class="calendar-header">
                <button class="btn btn-ghost btn-icon" onclick="app.prevMonth()">
                    ${icons.chevronLeft}
                </button>
                <span class="calendar-title">${monthName}</span>
                <button class="btn btn-ghost btn-icon" onclick="app.nextMonth()">
                    ${icons.chevronRight}
                </button>
            </div>
            <div class="calendar-grid">
    `;
    
    // Day headers
    dayNames.forEach(day => {
        calendarHTML += `<div class="calendar-day-header">${day}</div>`;
    });
    
    // Empty cells before first day
    for (let i = 0; i < startDay; i++) {
        calendarHTML += `<div class="calendar-day other-month"></div>`;
    }
    
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const entry = state.journalEntries.find(e => e.date === dateStr);
        const isToday = day === now.getDate() && month === now.getMonth() && year === now.getFullYear();
        
        let classes = 'calendar-day';
        if (isToday) classes += ' today';
        if (entry) classes += ` has-entry mood-${entry.mood}`;
        
        calendarHTML += `<div class="${classes}" onclick="app.openMoodDialog('${dateStr}')">${day}</div>`;
    }
    
    calendarHTML += `</div></div>`;
    return calendarHTML;
}

// Helper to check if a quote is liked (by text, not index)
function isQuoteLiked(quoteText) {
    const state = getState();
    return state.likedQuotes.some(q => q.text === quoteText);
}

// Comfort Corner
function renderComfortCorner() {
    const state = getState();
    const currentIndex = app.quoteIndex || 0;
    const quote = quotes[currentIndex];
    const isLiked = isQuoteLiked(quote.text);
    
    return `
        <div class="comfort-corner">
            <div class="comfort-header">
                ${icons.sparkles}
                <span>Comfort Corner</span>
                <span style="margin-left: auto; font-size: 0.75rem; opacity: 0.6;">${currentIndex + 1} / ${quotes.length}</span>
            </div>
            
            <div class="quote-container">
                <button class="quote-nav prev" onclick="app.prevQuote()">${icons.chevronLeft}</button>
                <div class="quote-content">
                    <blockquote class="quote-text">"${quote.text}"</blockquote>
                    <cite class="quote-author">— ${quote.author}</cite>
                </div>
                <button class="quote-nav next" onclick="app.nextQuote()">${icons.chevronRight}</button>
            </div>
            
            <div class="quote-actions">
                <button class="quote-action ${isLiked ? 'liked' : ''}" onclick="app.toggleLike(${currentIndex})">
                    ${isLiked ? icons.heartFilled : icons.heart}
                    <span>${isLiked ? 'Liked' : 'Like'}</span>
                </button>
                <button class="quote-action" onclick="app.copyQuote()">
                    ${icons.copy}
                    <span>Copy</span>
                </button>
                <button class="quote-action" onclick="app.shareQuote()">
                    ${icons.share}
                    <span>Share</span>
                </button>
            </div>
            
            <div class="quote-dots">
                ${quotes.map((_, i) => `
                    <button class="quote-dot ${i === currentIndex ? 'active' : ''}" onclick="app.goToQuote(${i})"></button>
                `).join('')}
            </div>
        </div>
    `;
}

// Bottom Navigation
function renderBottomNav() {
    const state = getState();
    return `
        <nav class="bottom-nav">
            <div class="nav-items">
                <button class="nav-item ${state.currentScreen === 'assessment' ? 'active' : ''}" onclick="app.navigate('assessment')">
                    ${icons.clipboard}
                    <span>Assessment</span>
                </button>
                <button class="nav-item ${state.currentScreen === 'journal-history' ? 'active' : ''}" onclick="app.navigate('journal-history')">
                    ${icons.book}
                    <span>Journal</span>
                </button>
                <button class="nav-item ${state.currentScreen === 'assessment-history' ? 'active' : ''}" onclick="app.navigate('assessment-history')">
                    ${icons.history}
                    <span>History</span>
                </button>
                <button class="nav-item ${state.currentScreen === 'comfort-corner' ? 'active' : ''}" onclick="app.navigate('comfort-corner')">
                    ${icons.sparkles}
                    <span>Comfort</span>
                </button>
            </div>
        </nav>
    `;
}

// Sidebar
function renderSidebar() {
    const state = getState();
    return `
        <div class="sidebar-overlay ${app.sidebarOpen ? 'open' : ''}" onclick="app.closeSidebar()"></div>
        <aside class="sidebar ${app.sidebarOpen ? 'open' : ''}">
            <div class="sidebar-header">
                <img src="/images/logo.svg" alt="MindEase" class="sidebar-logo">
                <div>
                    <h3 style="font-weight: 600;">MindEase</h3>
                    <p class="text-sm" style="color: var(--muted);">Mental Wellness</p>
                </div>
            </div>
            <nav class="sidebar-nav">
                <button class="sidebar-item ${state.currentScreen === 'home' ? 'active' : ''}" onclick="app.navigate('home')">
                    ${icons.home}
                    <span>Home</span>
                </button>
                <button class="sidebar-item ${state.currentScreen === 'assessment' ? 'active' : ''}" onclick="app.navigate('assessment')">
                    ${icons.clipboard}
                    <span>Take Assessment</span>
                </button>
                <button class="sidebar-item ${state.currentScreen === 'journal-history' ? 'active' : ''}" onclick="app.navigate('journal-history')">
                    ${icons.book}
                    <span>Journal History</span>
                </button>
                <button class="sidebar-item ${state.currentScreen === 'assessment-history' ? 'active' : ''}" onclick="app.navigate('assessment-history')">
                    ${icons.history}
                    <span>Assessment History</span>
                </button>
                <button class="sidebar-item ${state.currentScreen === 'comfort-corner' ? 'active' : ''}" onclick="app.navigate('comfort-corner')">
                    ${icons.sparkles}
                    <span>Comfort Corner</span>
                </button>
                <button class="sidebar-item ${state.currentScreen === 'profile' ? 'active' : ''}" onclick="app.navigate('profile')">
                    ${icons.user}
                    <span>Profile</span>
                </button>
            </nav>
        </aside>
    `;
}

// Assessment Screen
function renderAssessmentScreen() {
    if (app.assessmentComplete) {
        return renderAssessmentResult();
    }
    
    const currentQ = app.currentQuestion || 0;
    const answers = app.assessmentAnswers || new Array(assessmentQuestions.length).fill(-1);
    const progress = ((currentQ + 1) / assessmentQuestions.length) * 100;
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <span class="header-title">Stress Assessment</span>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            <div class="assessment-progress">
                <div class="progress-header">
                    <span>Question ${currentQ + 1} of ${assessmentQuestions.length}</span>
                    <span>${Math.round(progress)}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
            </div>
            
            <div class="card mb-6">
                <div class="card-content">
                    <p class="assessment-question">${assessmentQuestions[currentQ]}</p>
                </div>
            </div>
            
            <div class="answer-options">
                ${answerOptions.map(opt => `
                    <button class="answer-option ${answers[currentQ] === opt.value ? 'selected' : ''}" 
                            onclick="app.selectAnswer(${opt.value})">
                        ${opt.label}
                    </button>
                `).join('')}
            </div>
            
            <div class="assessment-nav">
                <button class="btn btn-secondary" onclick="app.prevQuestion()" ${currentQ === 0 ? 'disabled' : ''}>
                    ${icons.chevronLeft} Previous
                </button>
                <button class="btn btn-primary" onclick="app.nextQuestion()" ${answers[currentQ] === -1 ? 'disabled' : ''}>
                    ${currentQ === assessmentQuestions.length - 1 ? 'See Results' : 'Next'} ${currentQ < assessmentQuestions.length - 1 ? icons.chevronRight : ''}
                </button>
            </div>
        </main>
    `;
}

// Assessment Result
function renderAssessmentResult() {
    const result = app.assessmentResult;
    const info = severityInfo[result.severity];
    
    const severityClass = {
        'normal': 'severity-normal',
        'moderate': 'severity-moderate',
        'severe': 'severity-severe',
        'extremely-severe': 'severity-extreme'
    }[result.severity];
    
    const bgClass = {
        'normal': 'bg-severity-normal',
        'moderate': 'bg-severity-moderate',
        'severe': 'bg-severity-severe',
        'extremely-severe': 'bg-severity-extreme'
    }[result.severity];
    
    const iconSvg = result.severity === 'normal' ? icons.checkCircle : 
                    result.severity === 'moderate' ? icons.info : icons.alertTriangle;
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <span class="header-title">Assessment Result</span>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            <div class="card result-card ${bgClass}" style="border-width: 2px;">
                <div class="result-icon ${severityClass}">${iconSvg}</div>
                <h2 class="result-title ${severityClass}">${info.title}</h2>
                <p class="result-score">Score: ${result.score} / 40</p>
                <p class="result-description">${info.description}</p>
            </div>
            
            <div class="card recommendations mb-6">
                <div class="card-header">
                    <h3 class="card-title">Recommendations</h3>
                </div>
                <div class="card-content">
                    <ul>
                        ${info.tips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>
            </div>
            
            <div class="card mb-6 ${result.severity === 'extremely-severe' ? 'bg-severity-extreme' : ''}">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        ${icons.phone}
                        Professional Support Contacts
                    </h3>
                </div>
                <div class="card-content">
                    <p class="text-sm mb-4" style="color: var(--muted);">
                        ${result.severity === 'extremely-severe' 
                            ? "Please reach out to one of these resources for immediate support:"
                            : "If you need someone to talk to, these resources are available:"}
                    </p>
                    <div class="contacts-list">
                        ${emergencyContacts.map(c => `
                            <a href="tel:${c.number.replace(/[^0-9+]/g, '')}" class="contact-item">
                                <span class="contact-name">${c.name}</span>
                                <span class="contact-number">${c.number}</span>
                            </a>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="flex gap-3">
                <button class="btn btn-secondary" style="flex: 1;" onclick="app.retakeAssessment()">
                    Take Again
                </button>
                <button class="btn btn-primary" style="flex: 1;" onclick="app.navigate('home')">
                    Back to Home
                </button>
            </div>
        </main>
    `;
}

// Journal History Screen
function renderJournalHistoryScreen() {
    const state = getState();
    const entries = [...state.journalEntries].sort((a, b) => new Date(b.date) - new Date(a.date));
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <span class="header-title">Journal History</span>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            ${entries.length === 0 ? `
                <div class="empty-state">
                    <div class="empty-icon">${icons.book}</div>
                    <h3 class="empty-title">No journal entries yet</h3>
                    <p class="empty-description">Start tracking your mood by tapping on dates in the Mood Calendar on the home screen.</p>
                    <button class="btn btn-primary mt-4" onclick="app.navigate('home')">Go to Home</button>
                </div>
            ` : entries.map(entry => {
                const mood = getMoodData(entry.mood);
                return `
                    <div class="card journal-entry mb-4">
                        <div class="card-content">
                            <div class="journal-entry-header">
                                <div class="journal-entry-info">
                                    <div class="journal-mood-icon" style="background-color: ${mood.color}">
                                        ${mood.emoji}
                                    </div>
                                    <div>
                                        <p class="journal-entry-date">${formatDate(entry.date)}</p>
                                        <p class="journal-entry-mood">${mood.label}</p>
                                    </div>
                                </div>
                                <div class="journal-entry-actions">
                                    <button class="btn btn-ghost btn-icon" onclick="app.editJournalEntry('${entry.id}')">
                                        ${icons.edit}
                                    </button>
                                    <button class="btn btn-ghost btn-icon" style="color: var(--destructive);" onclick="app.deleteJournalEntry('${entry.id}')">
                                        ${icons.trash}
                                    </button>
                                </div>
                            </div>
                            ${entry.content ? `<p class="journal-entry-content">${entry.content}</p>` : ''}
                        </div>
                    </div>
                `;
            }).join('')}
        </main>
        
        ${renderBottomNav()}
    `;
}

// Assessment History Screen
function renderAssessmentHistoryScreen() {
    const state = getState();
    const results = [...state.assessmentResults].sort((a, b) => new Date(b.created_at || b.createdAt) - new Date(a.created_at || a.createdAt));
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <span class="header-title">Assessment History</span>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            ${results.length === 0 ? `
                <div class="empty-state">
                    <div class="empty-icon">${icons.clipboard}</div>
                    <h3 class="empty-title">No assessments yet</h3>
                    <p class="empty-description">Take a stress assessment to understand your current mental wellbeing and track your progress over time.</p>
                    <button class="btn btn-primary mt-4" onclick="app.navigate('assessment')">Take Assessment</button>
                </div>
            ` : `
                ${results.length > 1 ? `
                    <div class="card mb-4" style="background-color: rgba(79, 155, 143, 0.05); border-color: rgba(79, 155, 143, 0.2);">
                        <div class="card-content">
                            <h3 class="font-medium mb-2">Your Progress</h3>
                            <p class="text-sm" style="color: var(--muted);">
                                You've completed ${results.length} assessments.
                                ${results[0].score < results[results.length - 1].score
                                    ? " Your stress levels have improved since your first assessment."
                                    : results[0].score > results[results.length - 1].score
                                    ? " Keep practicing self-care to manage your stress levels."
                                    : " Your stress levels have remained stable."}
                            </p>
                        </div>
                    </div>
                ` : ''}
                
                ${results.map((result, index) => {
                    const config = severityConfig[result.severity];
                    let trendIcon = '';
                    if (index < results.length - 1) {
                        const prev = results[index + 1].score;
                        if (result.score > prev) trendIcon = `<span class="severity-severe">${icons.trendingUp}</span>`;
                        else if (result.score < prev) trendIcon = `<span class="severity-normal">${icons.trendingDown}</span>`;
                        else trendIcon = `<span style="color: var(--muted);">${icons.minus}</span>`;
                    }
                    
                    const createdAt = result.created_at || result.createdAt;
                    
                    return `
                        <div class="card mb-4 history-card" onclick="app.viewAssessmentDetail('${result.id}')" style="cursor: pointer;">
                            <div class="card-content">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="flex items-center gap-2 mb-1">
                                            <p class="font-medium">${formatDate(createdAt)}</p>
                                            ${trendIcon}
                                        </div>
                                        <p class="text-sm" style="color: var(--muted);">${formatTime(createdAt)}</p>
                                    </div>
                                    <div style="text-align: right;">
                                        <span class="badge ${config.bg} ${config.class}" style="padding: 0.25rem 0.75rem; border-radius: var(--radius-full); font-size: 0.875rem; font-weight: 500;">
                                            ${config.label}
                                        </span>
                                        <p class="text-xs mt-1" style="color: var(--muted);">Score: ${result.score}/40</p>
                                    </div>
                                </div>
                                <div style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                                    <p class="text-sm" style="color: var(--muted);">${config.remark}</p>
                                    <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation(); app.deleteAssessment('${result.id}')" style="color: var(--muted); padding: 0.25rem;">
                                        ${icons.x}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            `}
        </main>
        
        ${renderBottomNav()}
        
        ${app.viewingAssessmentId ? renderAssessmentDetailModal() : ''}
    `;
}

// Assessment Detail Modal
function renderAssessmentDetailModal() {
    const state = getState();
    const result = state.assessmentResults.find(r => r.id === app.viewingAssessmentId);
    if (!result) return '';
    
    const config = severityConfig[result.severity];
    const info = severityInfo[result.severity];
    const stressPercent = Math.round((result.score / 40) * 100);
    const createdAt = result.created_at || result.createdAt;
    
    return `
        <div class="modal-overlay" onclick="app.closeAssessmentDetail()">
            <div class="modal-content modal-large" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h2 class="modal-title">Assessment Details</h2>
                    <button class="btn btn-ghost btn-icon" onclick="app.closeAssessmentDetail()">
                        ${icons.x}
                    </button>
                </div>
                
                <div class="modal-body">
                    <!-- Summary Section -->
                    <div class="assessment-detail-summary">
                        <div class="flex items-center justify-between mb-4">
                            <div>
                                <p class="font-medium">${formatDate(createdAt)}</p>
                                <p class="text-sm" style="color: var(--muted);">${formatTime(createdAt)}</p>
                            </div>
                            <div style="text-align: right;">
                                <span class="badge ${config.bg} ${config.class}" style="padding: 0.5rem 1rem; border-radius: var(--radius-full); font-size: 1rem; font-weight: 600;">
                                    ${config.label}
                                </span>
                            </div>
                        </div>
                        
                        <!-- Stress Level Percentage -->
                        <div class="stress-meter-container">
                            <div class="stress-meter-header">
                                <span class="stress-meter-label">Stress Level</span>
                                <span class="stress-meter-value ${config.class}">${stressPercent}%</span>
                            </div>
                            <div class="stress-meter-bar">
                                <div class="stress-meter-fill ${config.bg}" style="width: ${stressPercent}%;"></div>
                            </div>
                            <div class="stress-meter-scale">
                                <span>0%</span>
                                <span>Low</span>
                                <span>Moderate</span>
                                <span>High</span>
                                <span>100%</span>
                            </div>
                        </div>
                        
                        <!-- Result Summary -->
                        <div class="result-box ${config.bg}" style="padding: 1rem; border-radius: var(--radius); margin-bottom: 1rem;">
                            <div class="flex items-center gap-2 mb-2">
                                ${icons.activity}
                                <h4 class="font-medium ${config.class}">${info.title}</h4>
                            </div>
                            <p class="text-sm" style="color: var(--foreground);">${info.description}</p>
                            <p class="text-xs mt-2" style="color: var(--muted);">Score: ${result.score} out of 40 points</p>
                        </div>
                    </div>
                    
                    <!-- Questions and Answers -->
                    <div class="assessment-detail-questions">
                        <h3 class="font-medium mb-3 flex items-center gap-2">
                            ${icons.clipboard}
                            Your Responses
                        </h3>
                        <div class="questions-list">
                            ${assessmentQuestions.map((question, index) => {
                                const answerValue = result.answers[index];
                                const answerOption = answerOptions.find(opt => opt.value === answerValue);
                                const answerLabel = answerOption?.label || 'Not answered';
                                return `
                                    <div class="question-item">
                                        <div class="question-number">Q${index + 1}</div>
                                        <div class="question-content">
                                            <p class="question-text">${question}</p>
                                            <div class="answer-badge ${config.bg}">
                                                <span class="answer-text ${config.class}">${answerLabel}</span>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="app.deleteAssessment('${result.id}'); app.closeAssessmentDetail();">
                        ${icons.x}
                        Delete
                    </button>
                    <button class="btn btn-primary" onclick="app.closeAssessmentDetail()">
                        Close
                    </button>
                </div>
            </div>
        </div>
    `;
}

// Comfort Corner Screen (Full)
function renderComfortCornerScreen() {
    const state = getState();
    const activeTab = app.comfortTab || 'browse';
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <div class="header-title">
                    ${icons.sparkles}
                    Comfort Corner
                </div>
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.home}
                </button>
            </div>
        </div>
        
        <main class="main-content">
            <div class="tabs">
                <div class="tab-list">
                    <button class="tab-trigger ${activeTab === 'browse' ? 'active' : ''}" onclick="app.setComfortTab('browse')">
                        Browse Quotes
                    </button>
                    <button class="tab-trigger ${activeTab === 'favorites' ? 'active' : ''}" onclick="app.setComfortTab('favorites')">
                        Favorites (${(state.likedQuotes || []).length})
                    </button>
                </div>
            </div>
            
            ${activeTab === 'browse' ? renderBrowseQuotes() : renderFavoriteQuotes()}
        </main>
        
        ${renderBottomNav()}
    `;
}

function renderBrowseQuotes() {
    const state = getState();
    const currentIndex = app.quoteIndex || 0;
    const quote = quotes[currentIndex];
    const isLiked = isQuoteLiked(quote.text);
    
    return `
        <p class="text-sm text-center mb-4" style="color: var(--muted);">
            Find comfort in these words of wisdom. Navigate through to discover quotes that resonate with you.
        </p>
        
        <div class="comfort-corner">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <button class="btn btn-ghost btn-sm" onclick="app.refreshQuotes()" style="display: flex; align-items: center; gap: 0.25rem; font-size: 0.75rem;">
                    ${icons.refresh}
                    <span>New Quotes</span>
                </button>
                <span class="text-xs" style="opacity: 0.6;">${currentIndex + 1} / ${quotes.length}</span>
            </div>
            
            <div class="quote-container">
                <button class="quote-nav prev" onclick="app.prevQuote()">${icons.chevronLeft}</button>
                <div class="quote-content">
                    <blockquote class="quote-text">"${quote.text}"</blockquote>
                    <cite class="quote-author">— ${quote.author}</cite>
                </div>
                <button class="quote-nav next" onclick="app.nextQuote()">${icons.chevronRight}</button>
            </div>
            
            <div class="quote-actions">
                <button class="quote-action ${isLiked ? 'liked' : ''}" onclick="app.toggleLike(${currentIndex})">
                    ${isLiked ? icons.heartFilled : icons.heart}
                    <span>${isLiked ? 'Liked' : 'Like'}</span>
                </button>
                <button class="quote-action" onclick="app.copyQuote()">
                    ${icons.copy}
                    <span>Copy</span>
                </button>
                <button class="quote-action" onclick="app.shareQuote()">
                    ${icons.share}
                    <span>Share</span>
                </button>
            </div>
            
            <div class="quote-dots">
                ${quotes.map((_, i) => `
                    <button class="quote-dot ${i === currentIndex ? 'active' : ''}" onclick="app.goToQuote(${i})"></button>
                `).join('')}
            </div>
        </div>
    `;
}

function renderFavoriteQuotes() {
    const state = getState();
    const likedQuotesList = state.likedQuotes || [];
    
    if (likedQuotesList.length === 0) {
        return `
            <div class="empty-state">
                <div class="empty-icon">${icons.heart}</div>
                <h3 class="empty-title">No favorites yet</h3>
                <p class="empty-description">Like quotes by tapping the heart icon to save them here for easy access.</p>
            </div>
        `;
    }
    
    return `
        <div class="favorites-list">
            ${likedQuotesList.map((quote, i) => `
                <div class="card favorite-quote mb-4">
                    <div class="card-content">
                        <blockquote class="quote-text" style="font-size: 1rem; margin-bottom: 0.5rem;">"${quote.text}"</blockquote>
                        <cite class="quote-author">— ${quote.author}</cite>
                        <div class="quote-actions" style="margin-top: 1rem; padding-top: 0.5rem; border-top: 1px solid var(--border);">
                            <button class="quote-action liked" onclick="app.toggleLikeByText('${quote.text.replace(/'/g, "\\'")}')">
                                ${icons.heartFilled}
                                <span>Unlike</span>
                            </button>
                            <button class="quote-action" onclick="app.copyQuoteObj({text: '${quote.text.replace(/'/g, "\\'")}', author: '${quote.author.replace(/'/g, "\\'")}' })">
                                ${icons.copy}
                                <span>Copy</span>
                            </button>
                            <button class="quote-action" onclick="app.shareQuoteObj({text: '${quote.text.replace(/'/g, "\\'")}', author: '${quote.author.replace(/'/g, "\\'")}' })">
                                ${icons.share}
                                <span>Share</span>
                            </button>
                        </div>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

// Profile Screen
function renderProfileScreen() {
    const state = getState();
    
    return `
        <div class="header">
            <div class="header-content">
                <button class="btn btn-ghost btn-icon" onclick="app.navigate('home')">
                    ${icons.arrowLeft}
                </button>
                <span class="header-title">Profile</span>
                <div style="width: 40px;"></div>
            </div>
        </div>
        
        <main class="main-content">
            <div class="card mb-6">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        ${icons.user}
                        Personal Settings
                    </h3>
                </div>
                <div class="card-content">
                    <div class="mb-4">
                        <label class="form-label">Display Name</label>
                        <div class="flex gap-2">
                            <input type="text" class="form-input" id="profile-name" value="${state.profile.name}" placeholder="Enter your name" oninput="app.handleProfileNameInput(this.value)">
                            <button class="btn btn-primary" onclick="app.saveName()">Save</button>
                        </div>
                    </div>
                    
                    <div class="switch-container">
                        <div class="switch-info">
                            ${state.isDarkMode ? icons.moon : icons.sun}
                            <div>
                                <p class="font-medium">Dark Mode</p>
                                <p class="text-sm" style="color: var(--muted);">
                                    ${state.isDarkMode ? 'Currently in dark mode' : 'Currently in light mode'}
                                </p>
                            </div>
                        </div>
                        <div class="switch ${state.isDarkMode ? 'active' : ''}" onclick="app.toggleDarkMode()"></div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-6">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        ${icons.info}
                        About MindEase
                    </h3>
                </div>
                <div class="card-content">
                    <p class="text-sm mb-4" style="color: var(--muted); line-height: 1.6;">
                        MindEase is your personal mental wellness companion designed to help you track your mood, assess your stress levels, and maintain a journal of your thoughts and feelings.
                    </p>
                    <p class="text-sm mb-4" style="color: var(--muted); line-height: 1.6;">
                        The stress assessment is based on the Perceived Stress Scale (PSS-10), a validated psychological instrument used worldwide to measure the perception of stress.
                    </p>
                    <div class="flex items-center gap-2 text-sm" style="color: var(--muted);">
                        ${icons.heart}
                        <span>Made with care for your mental wellbeing</span>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        ${icons.phone}
                        Emergency Hotlines
                    </h3>
                </div>
                <div class="card-content">
                    <p class="text-sm mb-4" style="color: var(--muted);">
                        If you or someone you know is in crisis, please reach out to these mental health resources:
                    </p>
                    <div class="contact-list">
                        ${emergencyContacts.map(contact => `
                            <a href="tel:${contact.number.replace(/[^0-9+]/g, '')}" class="contact-item">
                                <div>
                                    <p class="contact-name">${contact.name}</p>
                                    <p class="contact-number">${contact.number}</p>
                                </div>
                                ${icons.phone}
                            </a>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="card" style="background-color: rgba(79, 155, 143, 0.05); border-color: rgba(79, 155, 143, 0.2);">
                <div class="card-content">
                    <p class="text-xs" style="color: var(--muted); line-height: 1.6;">
                        <strong style="color: var(--foreground);">Disclaimer:</strong> MindEase is not a substitute for professional mental health care. If you are experiencing severe distress or having thoughts of self-harm, please contact a mental health professional or call emergency services immediately.
                    </p>
                </div>
            </div>
        </main>
    `;
}

// Mood Dialog Modal
function renderMoodDialog() {
    if (!app.moodDialogOpen) return '';
    
    const state = getState();
    const dateStr = app.selectedDate;
    const existingEntry = state.journalEntries.find(e => e.date === dateStr);
    const selectedMood = app.selectedMood || (existingEntry ? existingEntry.mood : null);
    const journalContent = app.journalContent !== undefined ? app.journalContent : (existingEntry ? existingEntry.content : '');
    
    return `
        <div class="modal-overlay open" onclick="app.closeMoodDialog(event)">
            <div class="modal" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3 class="modal-title">${formatDate(dateStr)}</h3>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label text-center">How are you feeling today?</label>
                        <div class="mood-options">
                            ${moods.map(mood => `
                                <button class="mood-option ${selectedMood === mood.value ? 'selected' : ''}" 
                                        onclick="app.selectMood('${mood.value}')">
                                    <span class="emoji">${mood.emoji}</span>
                                    <span class="label">${mood.label}</span>
                                </button>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Write about your day (optional)</label>
                        <textarea class="form-textarea" id="journal-content" placeholder="What's on your mind?" oninput="app.updateJournalDraft(this.value)">${journalContent}</textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" onclick="app.saveMoodEntry()" ${!selectedMood ? 'disabled' : ''}>
                        Save Entry
                    </button>
                </div>
            </div>
        </div>
    `;
}

// ============================================
// App Controller
// ============================================
const app = {
    sidebarOpen: false,
    quoteIndex: 0,
    calendarMonth: new Date().getMonth(),
    calendarYear: new Date().getFullYear(),
    moodDialogOpen: false,
    selectedDate: null,
    selectedMood: null,
    journalContent: '',
    currentQuestion: 0,
    assessmentAnswers: new Array(assessmentQuestions.length).fill(-1),
    assessmentComplete: false,
    assessmentResult: null,
    comfortTab: 'browse',
    editingEntryId: null,
    profileAutosaveDebounced: null,
    journalAutosaveDebounced: null,
    
    async init() {
        this.profileAutosaveDebounced = debounce((name) => this.persistProfileName(name), 600);
        this.journalAutosaveDebounced = debounce(() => this.persistJournalDraft(), 800);

        const state = getState();
        if (state.isDarkMode) {
            document.documentElement.classList.add('dark');
        }
        this.render();
        
        // Sync data from backend
        await syncFromBackend();
        await this.initRealtime();
        this.render();
    },

    async initRealtime() {
        try {
            const response = await fetch(`${API_BASE}/config`);
            if (!response.ok) {
                throw new Error('Missing realtime config');
            }

            const config = await response.json();
            const deviceId = getDeviceId();

            realtimeClient = createClient(config.supabase_url, config.supabase_anon_key);

            realtimeChannel = realtimeClient.channel(`mindease-device-${deviceId}`);
            const tables = ['journal_entries', 'assessment_results', 'profiles', 'liked_quotes'];

            tables.forEach((tableName) => {
                realtimeChannel.on(
                    'postgres_changes',
                    { event: '*', schema: 'public', table: tableName, filter: `device_id=eq.${deviceId}` },
                    async () => {
                        await syncFromBackend();
                        this.render();
                    }
                );
            });

            realtimeChannel.subscribe();
        } catch (error) {
            console.log('[v0] Realtime init failed:', error);
        }
    },

    teardownRealtime() {
        try {
            if (realtimeChannel) {
                realtimeClient.removeChannel(realtimeChannel);
                realtimeChannel = null;
            }
            realtimeClient = null;
        } catch (error) {
            console.log('[v0] Realtime teardown failed:', error);
        }
    },
    
    render() {
        const state = getState();
        const appEl = document.getElementById('app');
        
        let content = '';
        switch (state.currentScreen) {
            case 'welcome':
                content = renderWelcomeScreen();
                break;
            case 'home':
                content = renderHomeScreen();
                break;
            case 'assessment':
                content = renderAssessmentScreen();
                break;
            case 'journal-history':
                content = renderJournalHistoryScreen();
                break;
            case 'assessment-history':
                content = renderAssessmentHistoryScreen();
                break;
            case 'comfort-corner':
                content = renderComfortCornerScreen();
                break;
            case 'profile':
                content = renderProfileScreen();
                break;
            default:
                content = renderHomeScreen();
        }
        
        appEl.innerHTML = content + renderMoodDialog();
    },
    
    navigate(screen) {
        this.sidebarOpen = false;
        if (screen === 'assessment') {
            this.currentQuestion = 0;
            this.assessmentAnswers = new Array(assessmentQuestions.length).fill(-1);
            this.assessmentComplete = false;
            this.assessmentResult = null;
        }
        setState({ currentScreen: screen });
        this.render();
        window.scrollTo(0, 0);
    },
    
    handleGetStarted() {
        setState({ hasSeenWelcome: true, currentScreen: 'home' });
        this.render();
    },
    
    toggleSidebar() {
        this.sidebarOpen = !this.sidebarOpen;
        this.render();
    },
    
    closeSidebar() {
        this.sidebarOpen = false;
        this.render();
    },
    
    // Calendar
    prevMonth() {
        if (this.calendarMonth === 0) {
            this.calendarMonth = 11;
            this.calendarYear--;
        } else {
            this.calendarMonth--;
        }
        this.render();
    },
    
    nextMonth() {
        if (this.calendarMonth === 11) {
            this.calendarMonth = 0;
            this.calendarYear++;
        } else {
            this.calendarMonth++;
        }
        this.render();
    },
    
    // Mood Dialog
    openMoodDialog(dateStr) {
        const state = getState();
        const existingEntry = state.journalEntries.find(e => e.date === dateStr);
        this.moodDialogOpen = true;
        this.selectedDate = dateStr;
        this.selectedMood = existingEntry ? existingEntry.mood : null;
        this.journalContent = existingEntry ? existingEntry.content : '';
        this.editingEntryId = existingEntry ? existingEntry.id : null;
        this.render();
    },
    
    closeMoodDialog(event) {
        if (event && event.target !== event.currentTarget) return;
        this.moodDialogOpen = false;
        this.selectedDate = null;
        this.selectedMood = null;
        this.journalContent = '';
        this.editingEntryId = null;
        this.render();
    },
    
    selectMood(mood) {
        this.selectedMood = mood;
        this.render();
    },

    updateJournalDraft(value) {
        this.journalContent = value;
        if (this.selectedMood) {
            this.journalAutosaveDebounced();
        }
    },
    
    async saveMoodEntry() {
        const content = document.getElementById('journal-content')?.value || this.journalContent || '';
        
        // Save to backend
        const result = await apiPost('/journal', {
            date: this.selectedDate,
            mood: this.selectedMood,
            content
        });
        
        if (result) {
            // Sync from backend to get updated data
            await syncFromBackend();
            showToast('Entry saved', 'success');
        } else {
            showToast('Failed to save entry', 'error');
        }
        
        this.closeMoodDialog();
    },

    async persistJournalDraft() {
        if (!this.moodDialogOpen || !this.selectedDate || !this.selectedMood) return;
        const content = document.getElementById('journal-content')?.value || this.journalContent || '';
        await apiPost('/journal', {
            date: this.selectedDate,
            mood: this.selectedMood,
            content
        });
    },
    
    editJournalEntry(entryId) {
        const state = getState();
        const entry = state.journalEntries.find(e => e.id === entryId);
        if (entry) {
            this.openMoodDialog(entry.date);
        }
    },
    
    async deleteJournalEntry(entryId) {
        if (confirm('Are you sure you want to delete this entry? This action cannot be undone.')) {
            await apiDelete(`/journal/${entryId}`);
            await syncFromBackend();
            showToast('Entry deleted', 'success');
            this.render();
        }
    },
    
    // Quotes
    prevQuote() {
        this.quoteIndex = this.quoteIndex === 0 ? quotes.length - 1 : this.quoteIndex - 1;
        this.render();
    },
    
    nextQuote() {
        this.quoteIndex = this.quoteIndex === quotes.length - 1 ? 0 : this.quoteIndex + 1;
        this.render();
    },
    
    goToQuote(index) {
        this.quoteIndex = index;
        this.render();
    },
    
    async toggleLike(index) {
        const quote = quotes[index];
        
        // Save to backend
        const result = await apiPost('/liked-quotes', {
            quote_text: quote.text,
            quote_author: quote.author
        });
        
        if (result) {
            await syncFromBackend();
            if (result.action === 'liked') {
                showToast('Quote added to favorites', 'success');
            }
        }
        
        this.render();
    },
    
    async toggleLikeByText(quoteText) {
        const state = getState();
        const quote = state.likedQuotes.find(q => q.text === quoteText);
        
        if (quote) {
            await apiPost('/liked-quotes', {
                quote_text: quote.text,
                quote_author: quote.author
            });
            await syncFromBackend();
        }
        
        this.render();
    },
    
    copyQuote() {
        this.copyQuoteAt(this.quoteIndex);
    },
    
    copyQuoteAt(index) {
        const quote = quotes[index];
        this.copyQuoteObj(quote);
    },
    
    copyQuoteObj(quote) {
        const text = `"${quote.text}" - ${quote.author}`;
        navigator.clipboard.writeText(text).then(() => {
            showToast('Quote copied to clipboard', 'success');
        }).catch(() => {
            showToast('Failed to copy quote', 'error');
        });
    },
    
    shareQuote() {
        this.shareQuoteAt(this.quoteIndex);
    },
    
    shareQuoteAt(index) {
        const quote = quotes[index];
        this.shareQuoteObj(quote);
    },
    
    shareQuoteObj(quote) {
        const text = `"${quote.text}" - ${quote.author}\n\nShared from MindEase`;
        
        if (navigator.share) {
            navigator.share({ title: 'MindEase - Comfort Corner', text }).catch(() => {});
        } else {
            navigator.clipboard.writeText(text).then(() => {
                showToast('Quote copied to clipboard for sharing', 'success');
            });
        }
    },
    
    setComfortTab(tab) {
        this.comfortTab = tab;
        this.render();
    },
    
    refreshQuotes() {
        // Clear session quotes to get new ones
        sessionStorage.removeItem(SESSION_QUOTES_KEY);
        // Regenerate session quotes
        quotes = getSessionQuotes();
        this.quoteIndex = 0;
        showToast('New quotes loaded!', 'success');
        this.render();
    },
    
    // Assessment
    selectAnswer(value) {
        this.assessmentAnswers[this.currentQuestion] = value;
        this.render();
    },
    
    prevQuestion() {
        if (this.currentQuestion > 0) {
            this.currentQuestion--;
            this.render();
        }
    },
    
    nextQuestion() {
        if (this.currentQuestion < assessmentQuestions.length - 1) {
            this.currentQuestion++;
            this.render();
        } else {
            this.calculateResult();
        }
    },
    
    async calculateResult() {
        let totalScore = 0;
        this.assessmentAnswers.forEach((answer, index) => {
            if (reverseScoreQuestions.includes(index)) {
                totalScore += (4 - answer);
            } else {
                totalScore += answer;
            }
        });
        
        let severity;
        if (totalScore <= 13) severity = 'normal';
        else if (totalScore <= 20) severity = 'moderate';
        else if (totalScore <= 26) severity = 'severe';
        else severity = 'extremely-severe';
        
        this.assessmentResult = { score: totalScore, severity };
        this.assessmentComplete = true;
        
        // Save to backend
        const now = new Date();
        const result = await apiPost('/assessments', {
            date: now.toISOString().split('T')[0],
            score: totalScore,
            severity,
            answers: [...this.assessmentAnswers]
        });
        
        if (result) {
            await syncFromBackend();
        }
        
        this.render();
    },
    
    retakeAssessment() {
        this.currentQuestion = 0;
        this.assessmentAnswers = new Array(assessmentQuestions.length).fill(-1);
        this.assessmentComplete = false;
        this.assessmentResult = null;
        this.render();
    },
    
    viewAssessmentDetail(id) {
        this.viewingAssessmentId = id;
        this.render();
    },
    
    closeAssessmentDetail() {
        this.viewingAssessmentId = null;
        this.render();
    },
    
    async deleteAssessment(id) {
        // Call backend API to delete from database
        const result = await apiDelete(`/assessments/${id}`);
        
        if (result) {
            const state = getState();
            const updatedResults = state.assessmentResults.filter(r => r.id !== id);
            setState({ assessmentResults: updatedResults });
            showToast('Assessment deleted', 'success');
        } else {
            showToast('Failed to delete assessment', 'error');
        }
        
        this.render();
    },
    
    // Profile
    handleProfileNameInput(name) {
        setState({ profile: { ...getState().profile, name } });
        this.profileAutosaveDebounced(name);
    },

    async persistProfileName(name) {
        await apiPut('/profile', { name, avatar: null });
    },

    async saveName() {
        const name = document.getElementById('profile-name')?.value || '';
        
        // Save to backend
        const result = await apiPut('/profile', { name, avatar: null });
        
        if (result) {
            setState({ profile: { ...getState().profile, name } });
            showToast('Name saved', 'success');
        } else {
            showToast('Failed to save name', 'error');
        }
        
        this.render();
    },
    
    toggleDarkMode() {
        const state = getState();
        const newMode = !state.isDarkMode;
        setState({ isDarkMode: newMode });
        document.documentElement.classList.toggle('dark', newMode);
        this.render();
    }
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});

window.addEventListener('beforeunload', () => {
    app.teardownRealtime();
});

// Make app globally accessible
window.app = app;
