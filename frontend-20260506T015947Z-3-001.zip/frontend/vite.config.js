import { defineConfig } from 'vite';

const API_TARGET = process.env.MINDBACKEND_ORIGIN ?? 'http://127.0.0.1:8000';

export default defineConfig({
  root: '.',
  publicDir: 'public',
  server: {
    port: 3000,
    proxy: {
      // Frontend uses /api/... ; FastAPI mounts routes without the /api prefix (see vercel routing).
      '/api': {
        target: API_TARGET,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '') || '/',
      },
    },
  },
  build: {
    outDir: 'dist',
  },
});
